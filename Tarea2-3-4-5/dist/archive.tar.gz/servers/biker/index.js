import { bikerServer } from './biker-server'

bikerServer.listen();
bikerServer.start();