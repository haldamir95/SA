import { esbServer } from './esb-server'

esbServer.listen();
esbServer.start();